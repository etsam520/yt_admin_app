<script>
import ExcalidrawBoard from '@/components/ExcalidrawBoard.vue';

export default {
    name: 'DigitalExamBoard',
    components: {
        ExcalidrawBoard
    },
    data() {
        return {
            currentLanguage: 'en',
            currentIndex: 0,
            userAnswers: [],
            markedQuestions: [],
            showResults: false,
            currentQuestionTime: 0,
            questionTimer: null,
            showExcalidraw: false,
            excalidrawLoading: false,
            excalidrawError: null,
            excalidrawData: {},
            questionWorksheets: [], // Store Excalidraw data for each question
            examMeta: {
                timePerQuestion: 60, // seconds
                negativeMarking: true
            },
            questions: [
                {
                    en: {
                        text: 'What is the capital of France?',
                        options: ['London', 'Paris', 'Berlin', 'Madrid']
                    },
                    hi: {
                        text: 'फ्रांस की राजधानी क्या है?',
                        options: ['लंदन', 'पेरिस', 'बर्लिन', 'मैड्रिड']
                    },
                    marks: 1,
                    negative_mark: 0.25,
                    correct_answer: 1,
                    image: null
                },
                {
                    en: {
                        text: 'Which of these is not a programming language?',
                        options: ['Python', 'Java', 'HTML', 'C++']
                    },
                    hi: {
                        text: 'इनमें से कौन सी प्रोग्रामिंग भाषा नहीं है?',
                        options: ['पायथन', 'जावा', 'एचटीएमएल', 'सी++']
                    },
                    marks: 2,
                    negative_mark: 0.5,
                    correct_answer: 2,
                    image: null
                },
                {
                    en: {
                        text: 'What is the chemical symbol for Gold?',
                        options: ['Go', 'Gd', 'Au', 'Ag']
                    },
                    hi: {
                        text: 'सोने का रासायनिक प्रतीक क्या है?',
                        options: ['Go', 'Gd', 'Au', 'Ag']
                    },
                    marks: 1,
                    negative_mark: 0,
                    correct_answer: 2,
                    image: null
                }
            ]
        };
    },
    computed: {
        currentQuestion() {
            return this.questions[this.currentIndex];
        },
        attemptedCount() {
            return this.userAnswers.filter((answer) => answer !== undefined).length;
        },
        correctCount() {
            return this.userAnswers.reduce((count, answer, index) => {
                if (answer === this.questions[index].correct_answer) {
                    return count + 1;
                }
                return count;
            }, 0);
        },
        totalScore() {
            return this.userAnswers.reduce((score, answer, index) => {
                const question = this.questions[index];
                if (answer === question.correct_answer) {
                    return score + question.marks;
                } else if (answer !== undefined && question.negative_mark > 0) {
                    return score - question.negative_mark;
                }
                return score;
            }, 0);
        },
        totalPossibleMarks() {
            return this.questions.reduce((total, question) => total + question.marks, 0);
        },
        currentWorksheet() {
            const worksheet = this.questionWorksheets[this.currentIndex];
            // Return proper initial data structure if no worksheet exists
            return worksheet || {
                elements: [],
                appState: {
                    viewBackgroundColor: '#ffffff',
                    gridSize: null
                }
            };
        }
    },
    methods: {
        switchLanguage(lang) {
            this.currentLanguage = lang;
        },
        selectOption(optionIndex) {
            this.$set(this.userAnswers, this.currentIndex, optionIndex);
        },
        nextQuestion() {
            if (this.currentIndex < this.questions.length - 1) {
                this.currentIndex++;
                this.resetQuestionTimer();
                // Refresh Excalidraw with new question data if it's open
                if (this.showExcalidraw) {
                    this.refreshExcalidraw();
                }
            }
        },
        prevQuestion() {
            if (this.currentIndex > 0) {
                this.currentIndex--;
                this.resetQuestionTimer();
                // Refresh Excalidraw with new question data if it's open
                if (this.showExcalidraw) {
                    this.refreshExcalidraw();
                }
            }
        },
        goToQuestion(index) {
            this.currentIndex = index;
            this.resetQuestionTimer();
            // If Excalidraw is open, refresh it with the new question's data
            if (this.showExcalidraw) {
                this.showExcalidraw = false;
                this.$nextTick(() => {
                    this.showExcalidraw = true;
                });
            }
        },
        toggleMarkForReview() {
            const index = this.markedQuestions.indexOf(this.currentIndex);
            if (index === -1) {
                this.markedQuestions.push(this.currentIndex);
            } else {
                this.markedQuestions.splice(index, 1);
            }
        },
        finishExam() {
            clearInterval(this.questionTimer);
            this.showResults = true;
        },
        resetExam() {
            this.userAnswers = [];
            this.markedQuestions = [];
            this.questionWorksheets = [];
            this.currentIndex = 0;
            this.showResults = false;
            this.showExcalidraw = false;
            this.excalidrawLoading = false;
            this.excalidrawError = null;
            this.resetQuestionTimer();
        },
        resetQuestionTimer() {
            clearInterval(this.questionTimer);
            this.currentQuestionTime = this.examMeta.timePerQuestion;
            this.startQuestionTimer();
        },
        startQuestionTimer() {
            this.questionTimer = setInterval(() => {
                if (this.currentQuestionTime > 0) {
                    this.currentQuestionTime--;
                } else {
                    clearInterval(this.questionTimer);
                    // Auto move to next question if time expires
                    if (this.currentIndex < this.questions.length - 1) {
                        this.nextQuestion();
                    }
                }
            }, 1000);
        },
        formatTime(seconds) {
            const mins = Math.floor(seconds / 60);
            const secs = seconds % 60;
            return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
        },
        toggleExcalidraw() {
            console.log('Toggling Excalidraw, current state:', this.showExcalidraw);
            this.excalidrawError = null;
            this.excalidrawLoading = true;
            this.showExcalidraw = !this.showExcalidraw;
            
            if (this.showExcalidraw) {
                console.log('Opening Excalidraw with data:', this.currentWorksheet);
                this.$nextTick(() => {
                    this.excalidrawLoading = false;
                    console.log('Excalidraw should be loaded now');
                });
            } else {
                this.excalidrawLoading = false;
                console.log('Closing Excalidraw');
            }
        },
        onExcalidrawChange(data) {
            console.log('Excalidraw data changed for question', this.currentIndex + 1, ':', data);
            // Store the worksheet data for current question
            this.$set(this.questionWorksheets, this.currentIndex, data);
        },
        onExcalidrawError(error) {
            console.error('Excalidraw error:', error);
            this.excalidrawError = error.message || 'Failed to load worksheet';
            this.excalidrawLoading = false;
        },
        clearWorksheet() {
            // Clear the current question's worksheet
            this.$set(this.questionWorksheets, this.currentIndex, null);
            // Force refresh by toggling visibility
            this.showExcalidraw = false;
            this.$nextTick(() => {
                this.showExcalidraw = true;
            });
        },
        saveWorksheet() {
            // Save current worksheet data (could be extended to save to backend)
            const worksheetData = this.questionWorksheets[this.currentIndex];
            if (worksheetData) {
                console.log('Worksheet saved for question', this.currentIndex + 1, worksheetData);
                // Here you could implement saving to backend
            }
        },
        refreshExcalidraw() {
            // Force refresh Excalidraw component with new question data
            if (this.showExcalidraw) {
                this.showExcalidraw = false;
                this.$nextTick(() => {
                    this.showExcalidraw = true;
                });
            }
        }
    },
    mounted() {
        this.resetQuestionTimer();
        console.log('DigitalExamBoard mounted');
        
        // Check if ExcalidrawBoard component is available
        if (this.$options.components.ExcalidrawBoard) {
            console.log('ExcalidrawBoard component is available');
        } else {
            console.error('ExcalidrawBoard component is not available');
        }
    },
    beforeUnmount() {
        clearInterval(this.questionTimer);
    }
};
</script>

<template>
    <div class="exam-container" :class="{ 'hindi-font': currentLanguage === 'hi' }">
        <!-- Language Toggle -->
        <div class="language-toggle">
            <button @click="switchLanguage('en')" :class="{ active: currentLanguage === 'en' }">English</button>
            <button @click="switchLanguage('hi')" :class="{ active: currentLanguage === 'hi' }">हिंदी</button>
        </div>

        <!-- Exam Header -->
        <div class="exam-header">
            <h2>{{ currentLanguage === 'en' ? 'Practical Examination' : 'प्रायोगिक परीक्षा' }}</h2>
            <div class="exam-meta">
                <div class="timer">
                    {{ currentLanguage === 'en' ? 'Time Left:' : 'शेष समय:' }}
                    <span :class="{ 'time-warning': currentQuestionTime < 30 }">
                        {{ formatTime(currentQuestionTime) }}
                    </span>
                </div>
                <div class="marks-info">
                    {{ currentLanguage === 'en' ? 'Marks:' : 'अंक:' }} {{ currentQuestion.marks }}
                    <span v-if="currentQuestion.negative_mark > 0"> ({{ currentLanguage === 'en' ? 'Negative:' : 'नकारात्मक:' }} -{{ currentQuestion.negative_mark }}) </span>
                </div>
            </div>
        </div>

        <!-- Question Display -->
        <div class="question-slide">
            <div class="question-number">{{ currentLanguage === 'en' ? 'Question' : 'प्रश्न' }} {{ currentIndex + 1 }} {{ currentLanguage === 'en' ? 'of' : '/ ' }} {{ questions.length }}</div>

            <div class="question-text">
                {{ currentQuestion[currentLanguage]?.text || currentQuestion.en.text }}
            </div>

            <div v-if="currentQuestion.image" class="question-image">
                <img :src="currentQuestion.image" :alt="currentLanguage === 'en' ? 'Question diagram' : 'प्रश्न आरेख'" />
            </div>

            <div class="options-container">
                <div
                    v-for="(option, idx) in currentQuestion[currentLanguage]?.options || currentQuestion.en.options"
                    :key="idx"
                    class="option"
                    :class="{
                        selected: userAnswers[currentIndex] === idx,
                        correct: showResults && currentQuestion.correct_answer === idx,
                        incorrect: showResults && userAnswers[currentIndex] === idx && userAnswers[currentIndex] !== currentQuestion.correct_answer
                    }"
                    @click="selectOption(idx)"
                >
                    <span class="option-letter">{{ String.fromCharCode(65 + idx) }}</span>
                    <span class="option-text">{{ option }}</span>
                </div>
            </div>
        </div>

        <!-- Navigation Controls -->
        <div class="navigation-controls">
            <button @click="prevQuestion" :disabled="currentIndex === 0" class="nav-btn">
                {{ currentLanguage === 'en' ? 'Previous' : 'पिछला' }}
            </button>

            <button v-if="currentIndex < questions.length - 1" @click="nextQuestion" class="nav-btn">
                {{ currentLanguage === 'en' ? 'Next' : 'अगला' }}
            </button>

            <button v-else @click="finishExam" class="submit-btn">
                {{ currentLanguage === 'en' ? 'Submit Exam' : 'परीक्षा समाप्त करें' }}
            </button>

            <button @click="toggleMarkForReview" class="mark-btn" :class="{ marked: markedQuestions.includes(currentIndex) }">
                {{ currentLanguage === 'en' ? (markedQuestions.includes(currentIndex) ? 'Unmark' : 'Mark for Review') : markedQuestions.includes(currentIndex) ? 'अनमार्क करें' : 'समीक्षा के लिए चिह्नित करें' }}
            </button>

            <!-- Excalidraw Toggle Button -->
            <button @click="toggleExcalidraw" class="excalidraw-toggle-btn" :class="{ active: showExcalidraw }">
                {{ currentLanguage === 'en' ? (showExcalidraw ? 'Hide Worksheet' : 'Show Worksheet') : (showExcalidraw ? 'वर्कशीट छुपाएं' : 'वर्कशीट दिखाएं') }}
            </button>
        </div>

        <!-- Excalidraw Worksheet -->
        <div v-if="showExcalidraw" class="excalidraw-section">
            <div class="excalidraw-header">
                <h4>{{ currentLanguage === 'en' ? 'Digital Worksheet' : 'डिजिटल वर्कशीट' }}</h4>
                <div class="excalidraw-controls">
                    <button @click="clearWorksheet" class="worksheet-btn clear-btn">
                        {{ currentLanguage === 'en' ? 'Clear' : 'साफ़ करें' }}
                    </button>
                    <button @click="saveWorksheet" class="worksheet-btn save-btn">
                        {{ currentLanguage === 'en' ? 'Save' : 'सेव करें' }}
                    </button>
                </div>
            </div>
            <div class="excalidraw-container">
                <!-- Loading State -->
                <div v-if="excalidrawLoading" class="excalidraw-loading">
                    <div class="loading-spinner"></div>
                    <p>{{ currentLanguage === 'en' ? 'Loading worksheet...' : 'वर्कशीट लोड हो रही है...' }}</p>
                </div>
                
                <!-- Error State -->
                <div v-else-if="excalidrawError" class="excalidraw-error">
                    <p>{{ currentLanguage === 'en' ? 'Error loading worksheet:' : 'वर्कशीट लोड करने में त्रुटि:' }}</p>
                    <p>{{ excalidrawError }}</p>
                    <button @click="toggleExcalidraw" class="retry-btn">
                        {{ currentLanguage === 'en' ? 'Retry' : 'पुनः प्रयास करें' }}
                    </button>
                </div>
                
                <!-- Excalidraw Component -->
                <div v-else class="excalidraw-wrapper">
                    <ExcalidrawBoard
                        :key="`worksheet-${currentIndex}`"
                        :current-language="currentLanguage"
                        :teaching-mode="false"
                        :show-controls="true"
                        :initial-data="currentWorksheet"
                        @change="onExcalidrawChange"
                        @error="onExcalidrawError"
                    />
                </div>
            </div>
        </div>

        <!-- Question Progress -->
        <div class="question-progress">
            <div
                v-for="(question, idx) in questions"
                :key="idx"
                @click="goToQuestion(idx)"
                class="progress-dot"
                :class="{
                    current: idx === currentIndex,
                    attempted: userAnswers[idx] !== undefined,
                    marked: markedQuestions.includes(idx),
                    'has-worksheet': questionWorksheets[idx] !== undefined && questionWorksheets[idx] !== null
                }"
            >
                {{ idx + 1 }}
                <span v-if="questionWorksheets[idx]" class="worksheet-indicator">✏️</span>
            </div>
        </div>

        <!-- Results Modal -->
        <div v-if="showResults" class="results-modal">
            <div class="modal-content">
                <h3>{{ currentLanguage === 'en' ? 'Exam Results' : 'परीक्षा परिणाम' }}</h3>

                <div class="result-stats">
                    <p>{{ currentLanguage === 'en' ? 'Total Questions:' : 'कुल प्रश्न:' }} {{ questions.length }}</p>
                    <p>{{ currentLanguage === 'en' ? 'Attempted:' : 'प्रयास किए गए:' }} {{ attemptedCount }}</p>
                    <p>{{ currentLanguage === 'en' ? 'Correct Answers:' : 'सही उत्तर:' }} {{ correctCount }}</p>
                    <p>{{ currentLanguage === 'en' ? 'Questions with Worksheets:' : 'वर्कशीट वाले प्रश्न:' }} {{ questionWorksheets.filter(w => w).length }}</p>
                    <p>{{ currentLanguage === 'en' ? 'Score:' : 'अंक:' }} {{ totalScore.toFixed(2) }}/{{ totalPossibleMarks }}</p>
                </div>

                <button @click="resetExam" class="close-btn">
                    {{ currentLanguage === 'en' ? 'Close' : 'बंद करें' }}
                </button>
            </div>
        </div>
    </div>
</template>

<style scoped>
/* Base Styles */
.exam-container {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    background-color: #f5f7fa;
    border-radius: 10px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
}

.hindi-font {
    font-family: 'Nirmala UI', 'Arial Unicode MS', sans-serif;
}

/* Language Toggle */
.language-toggle {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 15px;
}

.language-toggle button {
    padding: 5px 10px;
    margin-left: 5px;
    border: 1px solid #ddd;
    background: #fff;
    cursor: pointer;
    border-radius: 4px;
}

.language-toggle button.active {
    background: #4caf50;
    color: white;
    border-color: #4caf50;
}

/* Exam Header */
.exam-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #ddd;
}

.exam-header h2 {
    margin: 0;
    color: #2c3e50;
}

.exam-meta {
    display: flex;
    gap: 20px;
}

.timer {
    font-weight: bold;
}

.time-warning {
    color: #e74c3c;
}

.marks-info {
    font-weight: bold;
    color: #3498db;
}

/* Question Slide */
.question-slide {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}

.question-number {
    font-weight: bold;
    color: #7f8c8d;
    margin-bottom: 15px;
}

.question-text {
    font-size: 18px;
    margin-bottom: 20px;
    line-height: 1.5;
}

.question-image {
    margin: 15px 0;
    text-align: center;
}

.question-image img {
    max-width: 100%;
    max-height: 200px;
    border-radius: 4px;
}

/* Options */
.options-container {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.option {
    display: flex;
    align-items: center;
    padding: 12px 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.2s;
}

.option:hover {
    background-color: #f0f0f0;
}

.option.selected {
    background-color: #e3f2fd;
    border-color: #2196f3;
}

.option.correct {
    background-color: #e8f5e9;
    border-color: #4caf50;
}

.option.incorrect {
    background-color: #ffebee;
    border-color: #f44336;
}

.option-letter {
    font-weight: bold;
    margin-right: 10px;
    color: #3498db;
}

/* Navigation Controls */
.navigation-controls {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
}

.nav-btn,
.submit-btn,
.mark-btn {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    transition: background-color 0.2s;
}

.nav-btn {
    background-color: #3498db;
    color: white;
}

.nav-btn:disabled {
    background-color: #bdc3c7;
    cursor: not-allowed;
}

.nav-btn:not(:disabled):hover {
    background-color: #2980b9;
}

.submit-btn {
    background-color: #2ecc71;
    color: white;
}

.submit-btn:hover {
    background-color: #27ae60;
}

.mark-btn {
    background-color: #f39c12;
    color: white;
}

.mark-btn.marked {
    background-color: #e74c3c;
}

.mark-btn:hover {
    opacity: 0.9;
}

.excalidraw-toggle-btn {
    background-color: #9b59b6;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    transition: background-color 0.2s;
}

.excalidraw-toggle-btn.active {
    background-color: #8e44ad;
}

.excalidraw-toggle-btn:hover {
    background-color: #7d3c98;
}

/* Excalidraw Section */
.excalidraw-section {
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    overflow: hidden;
}

.excalidraw-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 20px;
    background-color: #f8f9fa;
    border-bottom: 1px solid #dee2e6;
}

.excalidraw-header h4 {
    margin: 0;
    color: #2c3e50;
    font-size: 16px;
}

.excalidraw-controls {
    display: flex;
    gap: 10px;
}

.worksheet-btn {
    padding: 6px 12px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
    font-weight: bold;
    transition: all 0.2s;
}

.clear-btn {
    background-color: #e74c3c;
    color: white;
}

.clear-btn:hover {
    background-color: #c0392b;
}

.save-btn {
    background-color: #2ecc71;
    color: white;
}

.save-btn:hover {
    background-color: #27ae60;
}

.excalidraw-container {
    height: 400px;
    position: relative;
    background: #ffffff;
    border: 1px solid #e0e0e0;
}

.excalidraw-container > * {
    width: 100% !important;
    height: 100% !important;
}

.excalidraw-wrapper {
    width: 100%;
    height: 100%;
    position: relative;
}

.excalidraw-loading,
.excalidraw-error {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    text-align: center;
    color: #666;
}

.loading-spinner {
    width: 40px;
    height: 40px;
    border: 4px solid #f3f3f3;
    border-top: 4px solid #3498db;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-bottom: 10px;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.excalidraw-error {
    color: #e74c3c;
}

.retry-btn {
    margin-top: 10px;
    padding: 8px 16px;
    background-color: #3498db;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
}

.retry-btn:hover {
    background-color: #2980b9;
}

/* Question Progress */
.question-progress {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    justify-content: center;
    margin-top: 20px;
}

.progress-dot {
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background-color: #ecf0f1;
    cursor: pointer;
    font-weight: bold;
    transition: all 0.2s;
}

.progress-dot:hover {
    transform: scale(1.1);
}

.progress-dot.current {
    background-color: #3498db;
    color: white;
}

.progress-dot.attempted {
    background-color: #2ecc71;
    color: white;
}

.progress-dot.marked {
    background-color: #f39c12;
    color: white;
}

.progress-dot.has-worksheet {
    border: 2px solid #9b59b6;
    position: relative;
}

.worksheet-indicator {
    position: absolute;
    top: -5px;
    right: -5px;
    font-size: 10px;
    background: #9b59b6;
    border-radius: 50%;
    width: 16px;
    height: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Results Modal */
.results-modal {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
}

.modal-content {
    background-color: white;
    padding: 30px;
    border-radius: 10px;
    max-width: 500px;
    width: 90%;
    text-align: center;
}

.modal-content h3 {
    margin-top: 0;
    color: #2c3e50;
}

.result-stats {
    margin: 20px 0;
    text-align: left;
}

.result-stats p {
    margin: 10px 0;
    font-size: 16px;
}

.close-btn {
    padding: 10px 20px;
    background-color: #3498db;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
}

.close-btn:hover {
    background-color: #2980b9;
}

/* Responsive Design */
@media (max-width: 768px) {
    .exam-container {
        padding: 10px;
    }

    .exam-header {
        flex-direction: column;
        gap: 10px;
        text-align: center;
    }

    .exam-meta {
        flex-direction: column;
        gap: 5px;
    }

    .navigation-controls {
        flex-wrap: wrap;
        gap: 5px;
    }

    .nav-btn,
    .submit-btn,
    .mark-btn,
    .excalidraw-toggle-btn {
        flex: 1;
        min-width: 120px;
        padding: 8px 12px;
        font-size: 12px;
    }

    .excalidraw-container {
        height: 300px;
    }

    .excalidraw-header {
        flex-direction: column;
        gap: 10px;
        text-align: center;
    }

    .progress-dot {
        width: 30px;
        height: 30px;
        font-size: 12px;
    }

    .worksheet-indicator {
        width: 14px;
        height: 14px;
        font-size: 8px;
        top: -4px;
        right: -4px;
    }
}

@media (max-width: 480px) {
    .question-text {
        font-size: 16px;
    }

    .excalidraw-container {
        height: 250px;
    }

    .modal-content {
        padding: 20px;
        margin: 10px;
    }
}
</style>
