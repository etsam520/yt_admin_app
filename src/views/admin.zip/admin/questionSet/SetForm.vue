<script setup>
import { ref, reactive, computed, onMounted } from 'vue';
import { useToast } from 'primevue/usetoast';
import { apiClient } from '@/service/apiService';

const props = defineProps({
    isEdit: Boolean,
    initialData: {
        type: Object,
        default: () => ({
            name: '',
            description: '',
            is_active: true,
            is_public: false,
            password: null,
            organization: null,
            subject_id: null,
            chapter_id: null,
            topic_id: null,
            total_marks: 0,
            negative_mark: 0
        })
    }
});

const emit = defineEmits(['save', 'update', 'cancel']);

const toast = useToast();
const submitted = ref(false);
// const subjects = ref([])
// const chapters = ref([])
// const topics = ref([])

const form = reactive({
    ...props.initialData
});

const errors = reactive({
    name: '',
    password: ''
});

const organizations = ref([
    { name: 'Banking', value: 1 },
    { name: 'SSC', value: 2 },
    { name: 'ETS', value: 3 },
    { name: 'Railway', value: 4 }
]);

const statusOptions = ref([
    { label: 'Active', value: true },
    { label: 'Inactive', value: false }
]);

const visibilityOptions = ref([
    { label: 'Public', value: true },
    { label: 'Private', value: false }
]);

/*()
const requireChapter = computed(() => {
  if (!form.subject_id) return false
  const subject = subjects.value.find(s => s.id === form.subject_id)
  return subject?.has_chapters || false
})

const requireTopic = computed(() => {
  if (!form.chapter_id) return false
  const chapter = chapters.value.find(c => c.id === form.chapter_id)
  return chapter?.has_topics || false
})
*/
onMounted(async () => {
    // alert('SetForm mountedd');
    // await loadSubjects()
    loadOrganizations();

    // if (props.isEdit && form.subject_id) {
    //   await loadChapters()
    //   if (form.chapter_id) {
    //     await loadTopics()
    //   }
    // }
});

/*async function loadSubjects() {
  try {
    const response = await apiClient.get('/admin/category-by-depth-index', {
      params: { depth_index: 'subject' }
    })
    subjects.value = response.data.data.map(subject => ({
      ...subject,
      has_chapters: subject.children && subject.children.length > 0
    }))
  } catch (error) {
    showError('Failed to load subjects', error)
  }
}*/

const loadOrganizations = () => {
    // fetch data from API
    apiClient
        .get('/admin/organizations')
        .then((response) => {
            organizations.value = response.data.data;
        })
        .catch((error) => {
            toast.add({ severity: 'error', summary: 'Error', detail: 'Failed to load organizations', life: 3000 });
        });
};
/*
async function loadChapters() {
  form.chapter_id = null
  form.topic_id = null
  chapters.value = []
  topics.value = []
  
  if (!form.subject_id) return
  
  try {
    const response = await apiClient.get('/admin/category-by-depth-index', {
      params: { 
        parent_id: form.subject_id,
        depth_index: 'chapter'
      }
    })
    chapters.value = response.data.data.map(chapter => ({
      ...chapter,
      has_topics: chapter.children && chapter.children.length > 0
    }))
  } catch (error) {
    showError('Failed to load chapters', error)
  }
}

async function loadTopics() {
  form.topic_id = null
  topics.value = []
  
  if (!form.chapter_id) return
  
  try {
    const response = await apiClient.get('/admin/category-by-depth-index', {
      params: { 
        parent_id: form.chapter_id,
        depth_index: 'topic'
      }
    })
    topics.value = response.data.data
  } catch (error) {
    showError('Failed to load topics', error)
  }
}
*/
function validateForm() {
    submitted.value = true;
    let isValid = true;

    if (!form.name) {
        errors.name = 'Name is required';
        isValid = false;
    } else {
        errors.name = '';
    }

    if (!form.password && !props.isEdit) {
        errors.password = 'Password is required';
        isValid = false;
    } else {
        errors.password = '';
    }

    if (!form.organization && !props.isEdit) {
        isValid = false;
    }
    /*
  if (!form.subject_id && !props.isEdit) {
    isValid = false
  }

  if (requireChapter.value && !form.chapter_id && !props.isEdit) {
    isValid = false
  }

  if (requireTopic.value && !form.topic_id && !props.isEdit) {
    isValid = false
  }*/

    return isValid;
}

async function submitForm() {
    if (!validateForm()) return;

    try {
        if (props.isEdit) {
            // Update existing set
            const _set = { ...toRaw(form) };
            _set._method = 'PUT';
            await apiClient.post(`/admin/question-sets/${form.id}`, _set);
            toast.add({
                severity: 'success',
                summary: 'Success',
                detail: 'Set updated successfully',
                life: 3000
            });
            emit('update', form);
        } else {
            // Create new set
            const response = await apiClient.post('/admin/question-sets', form);
            toast.add({
                severity: 'success',
                summary: 'Success',
                detail: 'Set created successfully',
                life: 3000
            });
            emit('save', response.data);
        }
    } catch (error) {
        showError(props.isEdit ? 'Failed to update set' : 'Failed to create set', error);
    }
}

function showError(message, error) {
    console.error(error);
    toast.add({
        severity: 'error',
        summary: 'Error',
        detail: message,
        life: 5000
    });
}
</script>

<template>
    <div class="p-6 bg-white shadow-xl rounded-2xl max-w-4xl mx-auto">
        <h2 class="text-2xl font-semibold mb-6 text-gray-800">
            {{ isEdit ? 'Edit Set' : 'Create New Set' }}
        </h2>

        <div class="mb-4">
            <label for="name" class="block text-sm font-medium text-gray-700">Name *</label>
            <InputText id="name" v-model="form.name" :class="['mt-1 block w-full rounded-md border-gray-300 shadow-sm', { 'border-red-500': errors.name }]" required />
            <small v-if="errors.name" class="text-red-500">{{ errors.name }}</small>
        </div>

        <div class="mb-4">
            <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
            <Textarea id="description" v-model="form.description" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm" />
        </div>

        <div class="grid md:grid-cols-2 gap-6">
            <div>
                <label for="is_active" class="block text-sm font-medium text-gray-700">Status</label>
                <Select id="is_active" v-model="form.is_active" :options="statusOptions" optionLabel="label" optionValue="value" class="mt-1 w-full" />
            </div>

            <div>
                <label for="is_public" class="block text-sm font-medium text-gray-700">Visibility</label>
                <Select id="is_public" v-model="form.is_public" :options="visibilityOptions" optionLabel="label" optionValue="value" class="mt-1 w-full" />
            </div>
        </div>
        <!-- Marks Section -->
        <div class="mb-6 grid grid-cols-2 gap-4 mt-4">
            <div>
                <label class="block font-medium mb-2">Total Marks:</label>
                <InputNumber v-model="form.total_marks" class="w-full" :min="0" />
            </div>
            <div>
                <label class="block font-medium mb-2">Negative Mark:</label>
                <InputNumber v-model="form.negative_mark" class="w-full" :min="0" :max="Math.ceil(form.total_marks * 0.02)" />
            </div>
            <div>
                <label for="organization" class="block text-sm font-medium text-gray-700">Organization (Required)</label>
                <Dropdown id="organization" v-model="form.organization" :options="organizations" optionLabel="name" optionValue="id" placeholder="Select Organization" :class="{ 'p-invalid': submitted && !form.organization }" />
                <small class="p-error" v-if="submitted && !form.organization"> Organization is required. </small>
            </div>
        </div>

        <div class="mt-6" v-if="!isEdit">
            <label for="password" class="block text-sm font-medium text-gray-700">Password *</label>
            <Password id="password" v-model="form.password" :feedback="false" toggleMask :class="['mt-1 block w-full', { 'p-invalid border-red-500': errors.password }]" required />
            <small v-if="errors.password" class="text-red-500">{{ errors.password }}</small>
        </div>

        <div class="grid md:grid-cols-2 gap-6 mt-6" v-if="false">
            <div>
                <label for="subject" class="block text-sm font-medium text-gray-700">Subject *</label>
                <Select id="subject" v-model="form.subject_id" :options="subjects" optionLabel="name" optionValue="id" placeholder="Select Subject" :class="{ 'p-invalid': submitted && !form.subject_id }" @change="loadChapters" />
                <small class="p-error" v-if="submitted && !form.subject_id"> Subject is required. </small>
            </div>

            <div>
                <label for="chapter" class="block text-sm font-medium text-gray-700">Chapter</label>
                <Select
                    id="chapter"
                    :disabled="chapters.length == 0"
                    v-model="form.chapter_id"
                    :options="chapters"
                    optionLabel="name"
                    optionValue="id"
                    placeholder="Select Chapter"
                    :class="{ 'p-invalid': submitted && requireChapter && !form.chapter_id }"
                    @change="loadTopics"
                />
                <small class="p-error" v-if="submitted && requireChapter && !form.chapter_id"> Chapter is required for this subject. </small>
            </div>

            <div>
                <label for="topic" class="block text-sm font-medium text-gray-700">Topic</label>
                <Select id="topic" :desabled="topics.length == 0" v-model="form.topic_id" :options="topics" optionLabel="name" optionValue="id" placeholder="Select Topic" :class="{ 'p-invalid': submitted && requireTopic && !form.topic_id }" />
                <small class="p-error" v-if="submitted && requireTopic && !form.topic_id"> Topic is required for this chapter. </small>
            </div>
        </div>

        <div class="mt-8 flex justify-end space-x-4">
            <Button label="Cancel" icon="pi pi-times" class="bg-gray-100 hover:bg-gray-200 text-gray-800 border border-gray-300 rounded-lg px-4 py-2" @click="$emit('cancel')" />
            <Button :label="isEdit ? 'Update' : 'Create'" icon="pi pi-check" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2" @click="submitForm" />
        </div>
    </div>
</template>
