<template>
  <div class="canvas-teaching-container" :class="{ 'hindi-font': currentLanguage === 'hi' }">
    
    <!-- Minimal Left Sidebar with Expandable Controls -->
    <div v-if="isAnnotating" class="minimal-sidebar" :class="{ expanded: sidebarExpanded }">
      
      <!-- Sidebar Toggle -->
      <div class="sidebar-toggle" @click="toggleSidebar">
        <span v-if="!sidebarExpanded">⚙️</span>
        <span v-else>✖️</span>
      </div>

      <!-- Expandable Controls -->
      <div v-if="sidebarExpanded" class="expanded-controls">
        
        <!-- Stroke Colors -->
        <div class="mini-control-section">
          <div class="control-header" @click="toggleSection('colors')">
            <span class="control-icon">🎨</span>
            <span class="control-title">Colors</span>
            <span class="expand-icon" :class="{ rotated: expandedSections.colors }">▼</span>
          </div>
          <div v-if="expandedSections.colors" class="control-content">
            <div class="mini-color-grid">
              <div 
                v-for="color in strokeColors.slice(0, 8)" 
                :key="'stroke-' + color"
                :style="{ backgroundColor: color }"
                :class="{ active: currentStroke === color }"
                @click="setStrokeColor(color)"
                class="mini-color-box"
              ></div>
            </div>
          </div>
        </div>

        <!-- Stroke Width -->
        <div class="mini-control-section">
          <div class="control-header" @click="toggleSection('width')">
            <span class="control-icon">📏</span>
            <span class="control-title">Width</span>
            <span class="expand-icon" :class="{ rotated: expandedSections.width }">▼</span>
          </div>
          <div v-if="expandedSections.width" class="control-content">
            <div class="width-options">
              <div 
                v-for="width in [1, 2, 4, 8]" 
                :key="'width-' + width"
                :class="{ active: currentStrokeWidth === width }"
                @click="setStrokeWidth(width)"
                class="width-option"
              >
                <div class="width-preview" :style="{ height: width + 'px' }"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Background -->
        <div class="mini-control-section">
          <div class="control-header" @click="toggleSection('background')">
            <span class="control-icon">🎭</span>
            <span class="control-title">Background</span>
            <span class="expand-icon" :class="{ rotated: expandedSections.background }">▼</span>
          </div>
          <div v-if="expandedSections.background" class="control-content">
            <div class="mini-color-grid">
              <div 
                v-for="color in ['transparent', '#ffffff', '#f0f0f0', '#000000']" 
                :key="'bg-' + color"
                :style="{ backgroundColor: color === 'transparent' ? '#ffffff' : color }"
                :class="{ 
                  active: currentBackground === color,
                  transparent: color === 'transparent'
                }"
                @click="setBackgroundColor(color)"
                class="mini-color-box"
              >
                <div v-if="color === 'transparent'" class="transparent-pattern-mini"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Opacity -->
        <div class="mini-control-section">
          <div class="control-header" @click="toggleSection('opacity')">
            <span class="control-icon">🌫️</span>
            <span class="control-title">Opacity: {{ currentOpacity }}%</span>
            <span class="expand-icon" :class="{ rotated: expandedSections.opacity }">▼</span>
          </div>
          <div v-if="expandedSections.opacity" class="control-content">
            <input 
              type="range" 
              min="10" 
              max="100" 
              step="10"
              v-model="currentOpacity"
              class="mini-opacity-slider"
            >
          </div>
        </div>

      </div>
    </div>

    <!-- Minimal Top Toolbar with Zoom Shortcuts -->
    <div v-if="isAnnotating" class="minimal-top-toolbar">
      
      <!-- Drawing Tools - Compact -->
      <div class="compact-tools">
        <button 
          v-for="tool in quickTools" 
          :key="'tool-' + tool.name"
          :class="{ active: currentTool === tool.name }"
          @click="setTool(tool.name)"
          class="compact-tool-btn"
          :title="tool.label"
        >
          <span v-html="tool.icon"></span>
        </button>
      </div>

      <!-- Zoom Controls - Shortcuts -->
      <div class="zoom-shortcuts">
        <div class="zoom-display">{{ Math.round(zoomLevel * 100) }}%</div>
        <button @click="zoomOut" class="zoom-shortcut" title="Zoom Out (Ctrl + -)">-</button>
        <button @click="zoomIn" class="zoom-shortcut" title="Zoom In (Ctrl + +)">+</button>
        <button @click="resetZoom" class="zoom-shortcut" title="Reset Zoom (Ctrl + 0)">⌂</button>
      </div>

      <!-- Quick Actions -->
      <div class="quick-actions">
        <button @click="clearBoard" class="quick-action-btn" title="Clear Board">🗑️</button>
        <button @click="toggleGrid" class="quick-action-btn" :class="{ active: showGrid }" title="Toggle Grid">⊞</button>
      </div>

    </div>

    <!-- Main Content Area -->
    <div class="main-content" :class="{ 'with-minimal-sidebar': isAnnotating }">
      <!-- Canvas Container -->
      <div class="canvas-wrapper">
        <canvas 
          ref="teachingCanvas" 
          :width="canvasWidth * devicePixelRatio" 
          :height="canvasHeight * devicePixelRatio"
          :style="{ 
            width: canvasWidth + 'px', 
            height: canvasHeight + 'px',
            transform: `scale(${zoomLevel})`,
            transformOrigin: 'top left'
          }"
          @click="handleCanvasClick"
          @mousemove="handleCanvasHover"
          @mousedown="handleMouseDown"
          @mouseup="handleMouseUp"
          @mouseleave="handleMouseLeave"
          @wheel="handleWheel"
          @touchstart="handleTouchStart"
          @touchmove="handleTouchMove"
          @touchend="handleTouchEnd"
          @touchcancel="handleTouchEnd"
          class="teaching-canvas"
        ></canvas>
        
        <!-- Grid Overlay -->
        <div v-if="showGrid && isAnnotating" class="grid-overlay" 
             :style="{ 
               width: canvasWidth + 'px', 
               height: canvasHeight + 'px',
               transform: `scale(${zoomLevel})`,
               transformOrigin: 'top left'
             }">
        </div>
      </div>
    </div>
    
    <!-- Teaching Controls Panel -->
    <div class="teaching-controls">
      <button @click="toggleMode" class="mode-btn" :class="{ active: teachingMode === 'present' }">
        {{ currentLanguage === 'en' ? 'Presentation Mode' : 'प्रस्तुति मोड' }}
      </button>
      <button @click="toggleMode" class="mode-btn" :class="{ active: teachingMode === 'interactive' }">
        {{ currentLanguage === 'en' ? 'Interactive Mode' : 'इंटरैक्टिव मोड' }}
      </button>
      <button @click="toggleAnnotations" class="annotation-btn" :class="{ active: isAnnotating }">
        {{ currentLanguage === 'en' ? 'Draw Mode' : 'ड्रॉ मोड' }}
      </button>
      <button @click="toggleExcalidraw" class="excalidraw-btn" :class="{ active: useExcalidraw }">
        {{ currentLanguage === 'en' ? 'Excalidraw Mode' : 'एक्साड्रा मोड' }}
      </button>
      <button @click="clearBoard" class="clear-btn">
        {{ currentLanguage === 'en' ? 'Clear Board' : 'बोर्ड साफ़ करें' }}
      </button>
    </div>

    <!-- Excalidraw Integration -->
    <div v-if="useExcalidraw" class="excalidraw-overlay">
      <ExcalidrawBoard 
        :currentLanguage="currentLanguage"
        :teachingMode="teachingMode === 'interactive'"
        :showControls="true"
        @change="handleExcalidrawChange"
        @export="handleExcalidrawExport"
        @clear="handleExcalidrawClear"
        ref="excalidrawBoard"
      />
    </div>

    <!-- Drawing Toolbar -->
    <div v-if="isAnnotating" class="drawing-toolbar">
      <!-- Stroke Colors -->
      <div class="toolbar-section">
        <label>{{ currentLanguage === 'en' ? 'Stroke' : 'स्ट्रोक' }}</label>
        <div class="color-palette">
          <div 
            v-for="color in strokeColors" 
            :key="color"
            :style="{ backgroundColor: color }"
            :class="{ active: currentStroke === color }"
            @click="setStrokeColor(color)"
            class="color-swatch"
          ></div>
        </div>
      </div>

      <!-- Background Colors -->
      <div class="toolbar-section">
        <label>{{ currentLanguage === 'en' ? 'Background' : 'बैकग्राउंड' }}</label>
        <div class="color-palette">
          <div 
            v-for="color in backgroundColors" 
            :key="color"
            :style="{ backgroundColor: color }"
            :class="{ active: currentBackground === color }"
            @click="setBackgroundColor(color)"
            class="color-swatch"
          ></div>
        </div>
      </div>

      <!-- Stroke Width -->
      <div class="toolbar-section">
        <label>{{ currentLanguage === 'en' ? 'Stroke Width' : 'स्ट्रोक चौड़ाई' }}</label>
        <div class="stroke-width-options">
          <div 
            v-for="width in strokeWidths" 
            :key="width"
            :class="{ active: currentStrokeWidth === width }"
            @click="setStrokeWidth(width)"
            class="stroke-width-option"
          >
            <div :style="{ height: width + 'px', backgroundColor: currentStroke }"></div>
          </div>
        </div>
      </div>

      <!-- Stroke Style -->
      <div class="toolbar-section">
        <label>{{ currentLanguage === 'en' ? 'Stroke Style' : 'स्ट्रोक स्टाइल' }}</label>
        <div class="stroke-style-options">
          <div 
            v-for="style in strokeStyles" 
            :key="style.name"
            :class="{ active: currentStrokeStyle === style.name }"
            @click="setStrokeStyle(style.name)"
            class="stroke-style-option"
            :title="style.label"
          >
            <div :class="'stroke-' + style.name"></div>
          </div>
        </div>
      </div>

      <!-- Shape Tools -->
      <div class="toolbar-section">
        <label>{{ currentLanguage === 'en' ? 'Shapes' : 'आकार' }}</label>
        <div class="shape-tools">
          <button 
            v-for="shape in shapes" 
            :key="shape.name"
            :class="{ active: currentTool === shape.name }"
            @click="setTool(shape.name)"
            class="shape-tool"
            :title="shape.label"
          >
            <i :class="shape.icon"></i>
          </button>
        </div>
      </div>

      <!-- Edges -->
      <div class="toolbar-section">
        <label>{{ currentLanguage === 'en' ? 'Edges' : 'किनारे' }}</label>
        <div class="edge-options">
          <button 
            v-for="edge in edgeOptions" 
            :key="edge.name"
            :class="{ active: currentEdge === edge.name }"
            @click="setEdge(edge.name)"
            class="edge-option"
            :title="edge.label"
          >
            <i :class="edge.icon"></i>
          </button>
        </div>
      </div>

      <!-- Opacity -->
      <div class="toolbar-section">
        <label>{{ currentLanguage === 'en' ? 'Opacity' : 'पारदर्शिता' }}</label>
        <div class="opacity-control">
          <input 
            type="range" 
            min="0" 
            max="100" 
            v-model="currentOpacity"
            @input="updateOpacity"
            class="opacity-slider"
          >
          <span class="opacity-value">{{ currentOpacity }}%</span>
        </div>
      </div>

      <!-- Layers -->
      <div class="toolbar-section">
        <label>{{ currentLanguage === 'en' ? 'Layers' : 'लेयर्स' }}</label>
        <div class="layer-controls">
          <button @click="moveLayerUp" class="layer-btn" title="Move Up">
            <i class="fas fa-arrow-up"></i>
          </button>
          <button @click="moveLayerDown" class="layer-btn" title="Move Down">
            <i class="fas fa-arrow-down"></i>
          </button>
          <button @click="duplicateLayer" class="layer-btn" title="Duplicate">
            <i class="fas fa-copy"></i>
          </button>
          <button @click="deleteLayer" class="layer-btn" title="Delete">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
    </div>
    
    <!-- Hidden elements for text measurement -->
    <div ref="textMeasure" class="text-measure"></div>
    
    <!-- Summary Modal -->
    <div v-if="showSummary" class="summary-modal">
      <div class="modal-content">
        <h3>{{ currentLanguage === 'en' ? 'Teaching Session Summary' : 'शिक्षण सत्र सारांश' }}</h3>
        
        <div class="summary-stats">
          <p>
            {{ currentLanguage === 'en' ? 'Total Topics Covered:' : 'कुल विषय कवर किए गए:' }} {{ questions.length }}
          </p>
          <p>
            {{ currentLanguage === 'en' ? 'Topics Discussed:' : 'चर्चा किए गए विषय:' }} {{ discussedCount }}
          </p>
          <p>
            {{ currentLanguage === 'en' ? 'Interactive Questions:' : 'इंटरैक्टिव प्रश्न:' }} {{ interactiveCount }}
          </p>
          <p>
            {{ currentLanguage === 'en' ? 'Session Duration:' : 'सत्र अवधि:' }} {{ formatSessionTime() }}
          </p>
        </div>
        
        <button @click="resetSession" class="close-btn">
          {{ currentLanguage === 'en' ? 'End Session' : 'सत्र समाप्त करें' }}
        </button>
      </div>
    </div>

    <!-- Toggle Buttons -->
    <button 
      @click="toggleMode" 
      class="mode-toggle"
    >
      {{ teachingMode === 'present' 
        ? (currentLanguage === 'en' ? 'Switch to Interactive' : 'इंटरैक्टिव में स्विच करें')
        : (currentLanguage === 'en' ? 'Switch to Present' : 'प्रस्तुति में स्विच करें')
      }}
    </button>

    <button 
      @click="toggleAnnotations" 
      class="annotation-toggle"
      :class="{ active: isAnnotating }"
    >
      {{ isAnnotating 
        ? (currentLanguage === 'en' ? 'Exit Drawing' : 'ड्राइंग से बाहर निकलें')
        : (currentLanguage === 'en' ? 'Start Drawing' : 'ड्राइंग शुरू करें')
      }}
    </button>

    <!-- Session Summary Modal -->
    <div v-if="showSummary" class="summary-modal" @click.self="showSummary = false">
      <div class="summary-content">
        <h2>{{ currentLanguage === 'en' ? 'Teaching Session Summary' : 'शिक्षण सत्र सारांश' }}</h2>
        
        <div class="summary-stats">
          <div class="stat-item">
            <div class="stat-value">{{ topics.length }}</div>
            <div class="stat-label">{{ currentLanguage === 'en' ? 'Total Topics' : 'कुल विषय' }}</div>
          </div>
          
          <div class="stat-item">
            <div class="stat-value">{{ discussedCount }}</div>
            <div class="stat-label">{{ currentLanguage === 'en' ? 'Discussed' : 'चर्चित' }}</div>
          </div>
          
          <div class="stat-item">
            <div class="stat-value">{{ interactiveCount }}</div>
            <div class="stat-label">{{ currentLanguage === 'en' ? 'Interactive' : 'इंटरैक्टिव' }}</div>
          </div>
          
          <div class="stat-item">
            <div class="stat-value">{{ formatSessionTime() }}</div>
            <div class="stat-label">{{ currentLanguage === 'en' ? 'Session Time' : 'सत्र समय' }}</div>
          </div>
        </div>
        
        <div class="summary-actions">
          <button @click="resetSession" class="action-btn primary-btn">
            {{ currentLanguage === 'en' ? 'New Session' : 'नया सत्र' }}
          </button>
          <button @click="showSummary = false" class="action-btn secondary-btn">
            {{ currentLanguage === 'en' ? 'Close' : 'बंद करें' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
